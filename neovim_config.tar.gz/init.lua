--load vanilla nvim configs
require("config.options")
require("config.keybinds")

--loadd lazy
local lazypath = vim.fn.stdpath("data") .. "/lazy/lazy.nvim"
vim.opt.rtp:prepend(lazypath)

--Call lazy.setup() with a list of plugins
require("lazy").setup({

  -- ── Example plugins ─────────────────────────────────────
  { "nvim-treesitter/nvim-treesitter",                -- syntax highlighting + incremental parsing
    build = ":TSUpdate",
    event = "BufReadPost",                             -- load after a file is read
  },

  { "folke/which-key.nvim",                           -- show key bindings
    config = function() require("which-key").setup() end,
    keys = { "<leader>", mode = "n" },                 -- load when any <leader> key is pressed
  },

  { "folke/tokyonight.nvim",
    lazy = false,                -- load at startup so the colorscheme is ready immediately
    priority = 1000,             -- make sure it loads before other UI plugins
    config = function()
      vim.cmd("colorscheme tokyonight")   -- apply it
    end,
  },

   {
    'nvim-lualine/lualine.nvim',
    dependencies = { 'nvim-tree/nvim-web-devicons' },
   },
    --lsp man les gooo
  {
   "neovim/nvim-lspconfig",
    dependencies = {
      "williamboman/mason.nvim",
      "williamboman/mason-lspconfig.nvim",
    }
   },

    {
    "hrsh7th/nvim-cmp",
    dependencies = {
      "hrsh7th/cmp-nvim-lsp", -- LSP source for nvim-cmp
      "hrsh7th/cmp-buffer",   -- Buffer source
      "hrsh7th/cmp-path",     -- Path source
      "L3MON4D3/LuaSnip",     -- Snippet engine
      "saadparwaiz1/cmp_luasnip", -- Snippet source for nvim-cmp
    }
    }

})

--load plugin configs after
require("plugins.lualine")
require("plugins.lsp")
