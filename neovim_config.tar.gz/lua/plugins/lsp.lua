--setup mason
require("mason").setup()

-- Ensure clangd and lua_ls are installed
require("mason-lspconfig").setup({
  ensure_installed = { "clangd", "lua_ls" },
})

-- Get completion capabilities from nvim-cmp
local capabilities = require("cmp_nvim_lsp").default_capabilities()


--setup nvim-cmp
local cmp = require("cmp")
local luasnip = require("luasnip")

cmp.setup({
  snippet = {
    expand = function(args)
      luasnip.lsp_expand(args.body)
    end,
  },
  mapping = cmp.mapping.preset.insert({
    ["<C-b>"] = cmp.mapping.scroll_docs(-4),
    ["<C-f>"] = cmp.mapping.scroll_docs(4),
    ["<C-Space>"] = cmp.mapping.complete(), -- Trigger completion menu manually
    ["<C-e>"] = cmp.mapping.abort(),
    ["<CR>"] = cmp.mapping.confirm({ select = true }), -- Accept selected item

    -- Super-tab behavior for mapping navigation
    ["<Tab>"] = cmp.mapping(function(fallback)
      if cmp.visible() then
        cmp.select_next_item()
      elseif luasnip.expand_or_jumpable() then
        luasnip.expand_or_jump()
      else
        fallback()
      end
    end, { "i", "s" }),
    ["<S-Tab>"] = cmp.mapping(function(fallback)
      if cmp.visible() then
        cmp.select_prev_item()
      elseif luasnip.jumpable(-1) then
        luasnip.jump(-1)
      else
        fallback()
      end
    end, { "i", "s" }),
  }),
  sources = cmp.config.sources({
    { name = "nvim_lsp" }, -- Core LSP completions
    { name = "luasnip" },  -- Snippets
  }, {
    { name = "buffer" },   -- Text from current buffer
    { name = "path" },     -- File system paths
  }),
})

--and once and for all, activate LSP
vim.cmd("lsp enable")
