vim.g.mapleader = " "

vim.keymap.set("n", "<leader>cd", ":Ex<CR>")

vim.keymap.set("n", "<leader>l" , ":lsp enable<CR>")
