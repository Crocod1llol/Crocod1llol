vim.g.mapleader = " "

--good shortcuts
vim.keymap.set('n', '<leader>cd', ':Ex<CR>') --opens explorer

vim.keymap.set('n', '<leader>l' , ':lsp enable<CR>') --activates lsp
