vim.cmd("syntax enable")
vim.cmd("set number relativenumber")

--Indentation and tabs
vim.cmd("set tabstop=4")
 vim.cmd("set shiftwidth=4")
 vim.cmd("set autoindent")
 vim.cmd("set expandtab")

--Search
 vim.cmd("set ignorecase")
 vim.cmd("set smartcase")
 vim.cmd("set incsearch")
